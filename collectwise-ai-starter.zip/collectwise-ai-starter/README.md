# CollectWise AI — SaaS UI starter

This project turns the CollectWise AI Figma dashboard concept into a responsive Next.js + React + TypeScript interface.

## Included in this milestone
- Responsive dashboard shell and sidebar
- KPI cards, recovery chart styling, AI action recommendations
- Invoice table with search and status filtering
- CSV import into in-memory demo state
- Editable AI reminder draft modal
- Toast feedback and mobile navigation

## Important: this is not yet a production SaaS
The app uses illustrative sample metrics and in-memory state. Imported rows are not persisted after refresh. The reminder generator uses a local template; no AI provider or email service is connected. There is no authentication, multi-tenant database, subscription billing, or production security layer yet. Do not import real customer financial data until secure backend storage and access controls are implemented.

## Requirements
- Node.js 20.9 or newer
- npm
- VS Code (recommended)

## Run locally
1. Extract the ZIP.
2. Open the `collectwise-ai-starter` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open http://localhost:3000

## CSV import format
Use a CSV with a header row. Supported header names include:
- Customer (or Customer Name / Client)
- Amount (or Total / Invoice Amount)
- Invoice ID (or Invoice Number / ID), optional
- Due Date, optional

Example:

```csv
Customer,Invoice ID,Amount,Due Date
Northstar Studio,INV-1048,4800,2026-10-07
Brightpath Co.,INV-1031,2250,2026-10-23
```

The CSV parser in this starter is intentionally simple and does not yet support every edge case in RFC 4180, such as commas embedded inside quoted fields.

## Recommended next milestones
1. Backend API + PostgreSQL schema and migrations.
2. Authentication, organization membership and strict tenant isolation.
3. Persist invoices, import jobs and reminder drafts.
4. Connect an LLM through a server-side API route; validate output and keep human approval.
5. Add a verified email provider integration with send confirmation, logs and opt-out handling.
6. Add billing, quotas, audit events, backups, monitoring and deployment.
