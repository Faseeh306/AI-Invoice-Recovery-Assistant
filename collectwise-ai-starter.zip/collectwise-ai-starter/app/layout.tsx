import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CollectWise AI — Invoice Recovery",
  description: "A clearer way to manage receivables and payment follow-ups."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}