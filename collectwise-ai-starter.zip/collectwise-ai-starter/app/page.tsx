"use client";

import { ChangeEvent, useMemo, useRef, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Bell, CalendarClock,
  Check, ChevronDown, CircleHelp, Clock3, FileSpreadsheet, FileText, Filter,
  LayoutDashboard, LockKeyhole, Mail, Menu, MoreHorizontal, Plus, Search,
  Settings, Sparkles, Upload, Users, Wallet, X, Zap
} from "lucide-react";

type InvoiceStatus = "Overdue" | "Due today" | "Upcoming" | "Paid";
type Invoice = {
  id: string; customer: string; initials: string; amount: number;
  dueDate: string; status: InvoiceStatus; daysOverdue: number;
};

const initialInvoices: Invoice[] = [
  { id: "INV-2026-1048", customer: "Northstar Studio", initials: "N", amount: 4800, dueDate: "Oct 07, 2026", status: "Overdue", daysOverdue: 14 },
  { id: "INV-2026-1031", customer: "Brightpath Co.", initials: "B", amount: 2250, dueDate: "Oct 23, 2026", status: "Due today", daysOverdue: 0 },
  { id: "INV-2026-1019", customer: "Atlas Creative", initials: "A", amount: 1640, dueDate: "Oct 15, 2026", status: "Overdue", daysOverdue: 8 },
  { id: "INV-2026-1024", customer: "Mosaic Digital", initials: "M", amount: 980, dueDate: "Oct 22, 2026", status: "Overdue", daysOverdue: 1 },
  { id: "INV-2026-1007", customer: "Juniper Works", initials: "J", amount: 3120, dueDate: "Oct 29, 2026", status: "Upcoming", daysOverdue: 0 }
];

const navItems = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Invoices", icon: FileText },
  { label: "Recovery inbox", icon: Mail },
  { label: "Follow-up schedule", icon: CalendarClock },
  { label: "Customers", icon: Users },
  { label: "Reports & insights", icon: Activity }
];

const money = (n: number) => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD", maximumFractionDigits: 0
}).format(n);

export default function Home() {
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [activeNav, setActiveNav] = useState("Overview");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [modalInvoice, setModalInvoice] = useState<Invoice | null>(null);
  const [draft, setDraft] = useState("");
  const [toast, setToast] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const visibleInvoices = useMemo(() => invoices.filter((invoice) => {
    const query = search.toLowerCase();
    const matchesQuery = invoice.customer.toLowerCase().includes(query) || invoice.id.toLowerCase().includes(query);
    const matchesStatus = statusFilter === "All" || invoice.status === statusFilter;
    const matchesPage = activeNav !== "Invoices" || statusFilter === "All" || matchesStatus;
    return matchesQuery && matchesStatus && matchesPage;
  }), [invoices, search, statusFilter, activeNav]);

  const outstanding = invoices.filter(i => i.status !== "Paid").reduce((sum, i) => sum + i.amount, 0);
  const overdue = invoices.filter(i => i.status === "Overdue");
  const overdueTotal = overdue.reduce((sum, i) => sum + i.amount, 0);

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }

  function createDraft(invoice: Invoice) {
    const firstName = invoice.customer.split(" ")[0];
    setDraft(`Subject: Friendly reminder — invoice ${invoice.id}\n\nHi ${firstName} team,\n\nI hope you’re doing well. I’m following up on invoice ${invoice.id} for ${money(invoice.amount)}, which was due on ${invoice.dueDate}.\n\nWhen convenient, could you share an update on the expected payment date? If payment has already been arranged, please disregard this note. I’m happy to resend the invoice if helpful.\n\nThank you,\nYour Accounts Team`);
    setModalInvoice(invoice);
  }

  function parseCsv(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || "");
      const lines = text.split(/\r?\n/).filter(line => line.trim());
      if (lines.length < 2) { notify("CSV needs a header row and at least one invoice."); return; }
      const headers = lines[0].split(",").map(h => h.trim().toLowerCase().replaceAll(/["']/g, ""));
      const index = (names: string[]) => headers.findIndex(h => names.includes(h));
      const customerIndex = index(["customer", "customer name", "client"]);
      const idIndex = index(["invoice", "invoice id", "invoice number", "id"]);
      const amountIndex = index(["amount", "total", "invoice amount"]);
      const dueIndex = index(["due date", "duedate", "due"]);
      if (customerIndex < 0 || amountIndex < 0) {
        notify("CSV must include customer and amount columns.");
        return;
      }
      const imported: Invoice[] = lines.slice(1).map((line, i) => {
        const cells = line.split(",").map(v => v.trim().replace(/^["']|["']$/g, ""));
        const customer = cells[customerIndex] || "Unknown customer";
        const amount = Number((cells[amountIndex] || "0").replace(/[$,]/g, "")) || 0;
        const dueDate = cells[dueIndex] || "Not provided";
        const parsedDate = new Date(dueDate);
        const daysOverdue = Number.isNaN(parsedDate.getTime()) ? 0 : Math.max(0, Math.floor((Date.now() - parsedDate.getTime()) / 86400000));
        return {
          id: idIndex >= 0 && cells[idIndex] ? cells[idIndex] : `CSV-${Date.now()}-${i + 1}`,
          customer, initials: customer.charAt(0).toUpperCase(), amount, dueDate,
          status: daysOverdue > 0 ? "Overdue" as const : "Upcoming" as const, daysOverdue
        };
      }).filter(i => i.amount > 0);
      if (!imported.length) { notify("No valid invoice rows found."); return; }
      setInvoices(prev => [...imported, ...prev]);
      notify(`${imported.length} invoice(s) imported into this demo session.`);
      if (fileInput.current) fileInput.current.value = "";
    };
    reader.readAsText(file);
  }

  const pageTitle = activeNav === "Overview" ? "Receivables overview" : activeNav;
  const pageSubtitle = activeNav === "Overview"
    ? "A clear view of what’s owed, what’s at risk, and what to do next."
    : `Manage your ${activeNav.toLowerCase()} in one place.`;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">C</div>
          <div><div className="brand-name">collectwise</div><div className="brand-caption">AI RECEIVABLES</div></div>
          <button className="mobile-close icon-button" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation"><X size={18}/></button>
        </div>
        <div className="side-rule" />
        <div className="nav-label">WORKSPACE</div>
        <nav className="nav-list">
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${activeNav === label ? "active" : ""}`} onClick={() => { setActiveNav(label); setMobileNavOpen(false); }}>
              <Icon size={18} strokeWidth={1.8}/><span>{label}</span>
              {label === "Recovery inbox" && <span className="nav-count">3</span>}
            </button>
          ))}
        </nav>
        <div className="nav-label manage-label">MANAGE</div>
        <button className={`nav-item ${activeNav === "Settings" ? "active" : ""}`} onClick={() => setActiveNav("Settings")}><Settings size={18}/><span>Settings</span></button>
        <button className="nav-item" onClick={() => notify("Help centre will be connected in a later milestone.")}><CircleHelp size={18}/><span>Help & support</span></button>
        <div className="sidebar-bottom">
          <div className="plan-card"><span className="plan-badge">STARTER PREVIEW</span><strong>Keep your cash flow moving</strong><span className="plan-note">Upgrade and billing will be added later.</span></div>
          <div className="profile">
            <div className="avatar profile-avatar">FW</div><div className="profile-copy"><strong>Workspace owner</strong><span>Demo workspace</span></div><button className="profile-menu" aria-label="Profile menu" onClick={() => notify("Account settings are not connected yet.")}><MoreHorizontal size={19}/></button>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu icon-button" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Menu size={20}/></button>
            <span className="breadcrumb">Workspace <span>/</span> {activeNav}</span>
          </div>
          <div className="topbar-actions">
            <label className="search-box"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search invoices..." aria-label="Search invoices"/></label>
            <button className="icon-button notification-button" onClick={() => notify("You’re all caught up in this demo.")} aria-label="Notifications"><Bell size={18}/><i/></button>
            <button className="workspace-button" onClick={() => notify("Workspace switcher will be connected with authentication.")}><span className="avatar top-avatar">FW</span><span>My workspace</span><ChevronDown size={15}/></button>
          </div>
        </header>

        <div className="page-content">
          <section className="page-heading">
            <div><div className="eyebrow">FRIDAY, OCTOBER 23, 2026</div><h1>{pageTitle}</h1><p>{pageSubtitle}</p></div>
            <div className="heading-actions">
              <input ref={fileInput} type="file" accept=".csv,text/csv" hidden onChange={parseCsv}/>
              <button className="button button-primary" onClick={() => fileInput.current?.click()}><Plus size={17}/> Import invoices</button>
            </div>
          </section>

          {activeNav === "Overview" ? (
            <>
              <section className="stats-grid">
                <StatCard title="Total outstanding" value={money(outstanding)} trend="12.8%" caption="Across active invoices" tone="blue" icon={<Wallet size={18}/>}/>
                <StatCard title="Overdue invoices" value={String(overdue.length)} trend={`${money(overdueTotal)} at risk`} caption="Require follow-up" tone="amber" icon={<Clock3 size={18}/>}/>
                <StatCard title="Recovered this month" value="$26,480" trend="18.2%" caption="Illustrative demo metric" tone="green" icon={<ArrowUpRight size={18}/>}/>
                <StatCard title="Avg. days to pay" value="24.6 days" trend="3.1 days faster" caption="Illustrative demo metric" tone="purple" icon={<Activity size={18}/>}/>
              </section>

              <section className="middle-grid">
                <div className="panel recovery-panel">
                  <div className="panel-heading"><div><h2>Cash recovery trend</h2><p>Recovered payments over the last 6 months</p></div><span className="legend-pill"><i/> Collected</span></div>
                  <div className="chart-summary"><strong>$26,480</strong><span><ArrowUpRight size={15}/> 18.2% <em>vs previous month</em></span></div>
                  <div className="chart" role="img" aria-label="Illustrative recovery chart showing an upward trend">
                    <div className="chart-grid"><span>$30k</span><i/><span>$20k</span><i/><span>$10k</span><i/><span>$0</span><i/></div>
                    <div className="bar-set">{[32,43,38,56,49,69,61,77,67,88,79,100].map((h,i)=><div className={`bar ${i===11 ? "bar-current" : ""}`} key={i} style={{height:`${h}%`}} title={`Period ${i+1}`}/>)}</div>
                  </div>
                  <div className="chart-months"><span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span></div>
                  <div className="demo-note"><LockKeyhole size={13}/> Chart values are illustrative until connected to your accounting data.</div>
                </div>

                <div className="panel ai-panel">
                  <div className="panel-heading ai-heading"><div className="ai-title-icon"><Sparkles size={18}/></div><div><h2>AI recovery assistant</h2><p>Recommended next steps</p></div><span className="ai-count">3 actions</span></div>
                  <div className="recommendations">
                    <Recommendation number="01" tone="red" title="Follow up with Northstar Studio" detail="$4,800 overdue · 14 days" label="High priority" onClick={() => createDraft(invoices.find(i => i.customer === "Northstar Studio") || initialInvoices[0])}/>
                    <Recommendation number="02" tone="blue" title="Remind customers due soon" detail="Review upcoming invoice dates" label="Suggested" onClick={() => {setActiveNav("Invoices");setStatusFilter("Upcoming");}}/>
                    <Recommendation number="03" tone="amber" title="Confirm a promised payment" detail="Brightpath Co. · $2,250" label="Due today" onClick={() => createDraft(invoices.find(i => i.customer === "Brightpath Co.") || initialInvoices[1])}/>
                  </div>
                  <button className="button button-dark full-button" onClick={() => {setActiveNav("Recovery inbox");notify("Recovery inbox opened. Review each suggested action before sending.");}}>Review AI actions <ArrowRight size={15}/></button>
                  <div className="human-review-note"><LockKeyhole size={13}/> Drafts require your approval before sending.</div>
                </div>
              </section>
            </>
          ) : (
            <section className="panel section-panel">
              <div className="section-panel-head"><div className="section-icon"><FileSpreadsheet size={20}/></div><div><h2>{activeNav}</h2><p>This section uses the same CollectWise design system.</p></div></div>
              <p className="section-explainer">{activeNav === "Invoices" ? "Search and filter your imported invoice records below." : activeNav === "Recovery inbox" ? "AI-generated reminder drafts are reviewed here before any message is sent." : activeNav === "Follow-up schedule" ? "Plan payment follow-ups around invoice due dates and customer promises." : activeNav === "Customers" ? "Customer account summaries will appear here when customer records are connected." : activeNav === "Reports & insights" ? "Review collection performance, overdue aging and recovery trends." : "Workspace preferences, team access and integrations will be configured here."}</p>
              {activeNav !== "Invoices" && <div className="coming-soon"><Zap size={17}/><span>UI foundation ready · Backend integration is the next milestone.</span></div>}
            </section>
          )}

          <section className="panel invoice-panel">
            <div className="invoice-heading"><div><h2>{activeNav === "Invoices" ? "All invoices" : "Invoices that need attention"}</h2><p>Keep your follow-ups moving with the highest-priority accounts.</p></div><div className="invoice-tools"><label className="filter-select"><Filter size={14}/><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} aria-label="Filter invoice status"><option>All</option><option>Overdue</option><option>Due today</option><option>Upcoming</option><option>Paid</option></select></label><button className="text-link" onClick={() => {setActiveNav("Invoices");setStatusFilter("All");}}>View all invoices <ArrowRight size={14}/></button></div></div>
            <div className="table-wrap"><table><thead><tr><th>Customer / invoice</th><th>Amount</th><th>Due date</th><th>Status</th><th>AI suggestion</th><th aria-label="Actions"/></tr></thead>
              <tbody>{visibleInvoices.length ? visibleInvoices.map((invoice, index) => (
                <tr key={invoice.id}>
                  <td><div className="customer-cell"><div className={`avatar customer-avatar avatar-${index%4}`}>{invoice.initials}</div><div><strong>{invoice.customer}</strong><span>{invoice.id}</span></div></div></td>
                  <td className="amount-cell">{money(invoice.amount)}</td><td className="date-cell">{invoice.dueDate}</td>
                  <td><StatusPill status={invoice.status} days={invoice.daysOverdue}/></td>
                  <td><button className="action-pill" onClick={() => createDraft(invoice)}><Sparkles size={13}/>{invoice.status === "Due today" ? "Confirm payment" : invoice.status === "Upcoming" ? "Prepare reminder" : "Draft reminder"}</button></td>
                  <td><button className="row-menu" onClick={() => createDraft(invoice)} aria-label={`Create reminder for ${invoice.customer}`}><MoreHorizontal size={18}/></button></td>
                </tr>
              )) : <tr><td colSpan={6} className="empty-state">No invoices match your search and filters.</td></tr>}</tbody>
            </table></div>
            <div className="table-footer"><span>Showing <strong>{visibleInvoices.length}</strong> of {invoices.length} demo invoices</span><span>Sample data · Not connected to accounting software</span></div>
          </section>
          <footer className="footer"><span>© 2026 CollectWise AI · Demo workspace</span><span><LockKeyhole size={13}/> Your production data will require secure backend storage.</span></footer>
        </div>
      </main>

      {modalInvoice && <div className="modal-backdrop" role="presentation" onMouseDown={e => {if(e.target === e.currentTarget) setModalInvoice(null);}}>
        <section className="draft-modal" role="dialog" aria-modal="true" aria-labelledby="draft-title">
          <div className="modal-header"><div className="modal-title-icon"><Sparkles size={19}/></div><div><h2 id="draft-title">AI reminder draft</h2><p>{modalInvoice.customer} · {modalInvoice.id}</p></div><button className="icon-button" onClick={() => setModalInvoice(null)} aria-label="Close draft"><X size={19}/></button></div>
          <div className="draft-safety"><LockKeyhole size={14}/> Review and edit this draft. Nothing will be sent from this demo.</div>
          <label className="draft-label" htmlFor="draft-content">Message</label><textarea id="draft-content" value={draft} onChange={e => setDraft(e.target.value)} rows={12}/>
          <div className="modal-actions"><button className="button button-secondary" onClick={() => {navigator.clipboard?.writeText(draft);notify("Draft copied to clipboard.");}}>Copy draft</button><button className="button button-primary" onClick={() => {setModalInvoice(null);notify("Draft saved in this demo session. No email was sent.");}}><Check size={16}/> Save draft</button></div>
        </section>
      </div>}
      {toast && <div className="toast"><Check size={16}/>{toast}<button onClick={() => setToast("")} aria-label="Dismiss notification"><X size={14}/></button></div>}
    </div>
  );
}

function StatCard({title,value,trend,caption,tone,icon}:{title:string;value:string;trend:string;caption:string;tone:string;icon:React.ReactNode}) {
  return <article className="stat-card"><div className="stat-top"><span className={`stat-icon ${tone}`}>{icon}</span><span className="stat-title">{title}</span></div><strong className="stat-value">{value}</strong><div className="stat-bottom"><span className={`stat-trend ${tone}`}>{tone === "amber" ? <ArrowDownRight size={13}/> : <ArrowUpRight size={13}/>} {trend}</span><span className="stat-caption">{caption}</span></div></article>;
}

function Recommendation({number,tone,title,detail,label,onClick}:{number:string;tone:string;title:string;detail:string;label:string;onClick:()=>void}) {
  return <button className="recommendation" onClick={onClick}><span className={`recommendation-number ${tone}`}>{number}</span><span className="recommendation-copy"><strong>{title}</strong><small>{detail}</small></span><span className={`recommendation-label ${tone}`}>{label}</span></button>;
}

function StatusPill({status,days}:{status:InvoiceStatus;days:number}) {
  const cls = status === "Overdue" ? "status-overdue" : status === "Due today" ? "status-today" : status === "Paid" ? "status-paid" : "status-upcoming";
  const label = status === "Overdue" ? `${days} ${days === 1 ? "day" : "days"} overdue` : status;
  return <span className={`status-pill ${cls}`}><i/>{label}</span>;
}